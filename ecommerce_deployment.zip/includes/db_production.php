<?php
// Production database configuration for 000webhost
// Replace these values with your actual 000webhost database credentials

$host = 'localhost';  // Usually localhost for 000webhost
$dbname = 'your_database_name';  // Replace with your actual database name
$user = 'your_username';  // Replace with your actual username
$password = 'your_password';  // Replace with your actual password

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
